﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Rectangle
{
    public int A { get; set; }
    public int B { get; set; }
    public Rectangle()
    {

    }
    public Rectangle(int a, int b)
    {
        this.A = a;
        this.B = b;
    }

    public void Draw(int a, int b)
    {
        Console.WriteLine("|" + new string('-', a) + "|");
        for (int i = 0; i < b- 2; i++)
        {
            Console.Write("|");
            Console.Write(new string(' ', a));
            Console.Write("|");
            Console.WriteLine();
        }
        Console.WriteLine("|" + new string('-', a) + "|");
    }
}

