﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


class DrawingTool
{
    public Rectangle Rectangle { get; set; }
    public Square Square { get; set; }
    public DrawingTool()
    {

    }
    public DrawingTool(Rectangle rectangle)
    {
        this.Rectangle = rectangle;
    }
    public DrawingTool(Square square)
    {
        this.Square = square;
    }
}

