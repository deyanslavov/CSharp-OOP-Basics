﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Company
{
    private string name;
    public string Name
    {
        get { return this.name; }
        set { name = value; }
    }
    private string department;
    public string Department
    {
        get { return this.department; }
        set { department = value; }
    }
    private decimal salary;
    public decimal Salary
    {
        get { return this.salary; }
        set { salary = value; }
    }
    public Company()
    {
    }
    public Company(string name, string department, decimal salary)
    {
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    public override string ToString()
    {
        return this.name + " " + this.department + " " + string.Format("{0:0.00}", this.salary);
    }
}
