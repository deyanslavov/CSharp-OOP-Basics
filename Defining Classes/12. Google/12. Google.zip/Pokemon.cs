﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Pokemon
{
    private string name;
    public string Name
    {
        get { return this.name; }
        set { name = value; }
    }
    private string type;
    public string Type
    {
        get { return this.type; }
        set { type = value; }
    }
    public Pokemon()
    {
    }
    public Pokemon(string name, string type)
    {
        this.name = name;
        this.type = type;
    }

    public override string ToString()
    {
        return this.Name + " " + this.type;
    }
}
