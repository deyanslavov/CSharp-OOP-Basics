﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Child
{
    private string name;
    public string Name
    {
        get { return this.name; }
        set { name = value; }
    }
    private string birthday;
    public string Birthday
    {
        get { return this.birthday; }
        set { birthday = value; }
    }
    public Child()
    {
    }
    public Child(string name, string birthday)
    {
        this.name = name;
        this.birthday = birthday;
    }
    public override string ToString()
    {
        return this.name + " " + this.birthday;
    }
}
