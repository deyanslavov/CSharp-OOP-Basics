﻿public class Point
{
    private double x;
    public double X
    {
        get { return this.x; }
        set { x = value; }
    }

    private double y;
    public double Y
    {
        get { return this.y; }
        set { y = value; }
    }
    public Point()
    {
    }
}