﻿using System;

public class Rectangle
{
    private string id;
    public string Id
    {
        get { return this.id; }
        set { id = value; }
    }

    private double width;
    public double Width
    {
        get { return this.width; }
        set { width = value; }
    }

    private double height;
    public double Height
    {
        get { return this.height; }
        set { height = value; }
    }

    private Point topLeft;
    public Point TopLeft
    {
        get { return this.topLeft; }
        set { topLeft = value; }
    }

    public Rectangle()
    {
    }

    public bool IntersectsWith(Rectangle rectangle)
    {
        return rectangle.topLeft.X + rectangle.width >= this.topLeft.X &&
                rectangle.topLeft.X <= this.topLeft.X + this.width &&
                rectangle.topLeft.Y >= this.topLeft.Y - this.height &&
                rectangle.topLeft.Y - rectangle.height <= this.topLeft.Y;
    }
}