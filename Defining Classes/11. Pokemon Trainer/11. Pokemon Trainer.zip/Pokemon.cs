﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Pokemon
{
    private string name;
    private string element;
    private int health;

    public string Name
    {
        get { return this.name; }
        set { name = value; }
    }

    public string Element
    {
        get { return this.element; }
        set { element = value; }
    }

    public int Health
    {
        get { return this.health; }
        set { health = value; }
    }

    public Pokemon()
    {
    }
    public Pokemon(string name, string element, int health)
    {
        this.name = name;
        this.element = element;
        this.health = health;
    }
}
