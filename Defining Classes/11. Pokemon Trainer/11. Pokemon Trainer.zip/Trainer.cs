﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Trainer
{
    private string name;
    private int badges;
    private List<Pokemon> pokemons;

    public string Name
    {
        get { return this.name; }
        set { name = value; }
    }

    public int Badges
    {
        get { return this.badges; }
        set { badges = value; }
    }

    public List<Pokemon> Pokemons
    {
        get { return this.pokemons; }
        set { pokemons = value; }
    }
    public Trainer()
    {
        this.pokemons = new List<Pokemon>();
    }
    public Trainer(string name, int badges, List<Pokemon> pokemons)
    {
        this.name = name;
        this.badges = badges;
        this.pokemons = pokemons;
    }
}
